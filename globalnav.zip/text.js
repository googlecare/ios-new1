window.defaultNumber = '+1(888) 844-9528‬‬‬';
window.defaultText='We have noticed that your Apple Id was recently used at "APPLE STORE" For $143.95, Paid by Apple Pay Pre Authorization. If NOT you? Please call +1 ‪(888) 844-9528 Talk to an Apple Representative.!';

